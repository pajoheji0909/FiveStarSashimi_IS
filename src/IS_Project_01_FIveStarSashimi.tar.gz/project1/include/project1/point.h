
struct point{
	double x;
	double y;
	double th;
};
